import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

public class tic extends JFrame implements ActionListener {

	private JButton[][] button = new JButton[3][3];
	private JLabel label;
	private JPanel panel1, panel2;

	int count = 0;


	public tic() 
	{

		setTitle("Tic Tac Toe Game");
		setSize(290, 290);
		JPanel panel1 = new JPanel(); // ��ư
		panel1.setLayout(new GridLayout(3, 3, 1, 1));


		for (int a = 0; a < 3; a++) {
			for (int s = 0; s < 3; s++) {
				button[a][s] = new JButton(" ");
				button[a][s].addActionListener(this);
				panel1.add(button[a][s]);
			}
		}

		panel2 = new JPanel(); // ���� ��� ���

		add(panel1, BorderLayout.CENTER);
		add(panel2, BorderLayout.SOUTH);
		setVisible(true);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		for (int a = 0; a < 3; a++) {
			for (int s = 0; s < 3; s++) {
				if (e.getSource() == button[a][s] && button[a][s].getText().equals(" ")) {
					button[a][s].setText("O"); // ��
					count++;
				}
			}
		}

		while (true) {
			int rand1 = (int) (Math.random() * 3), rand2 = (int) (Math.random() * 3);
			
			if (count == 9)
				break;
			
			if (button[rand1][rand2].getText().equals(" ")) {
				button[rand1][rand2].setText("X");
				count++;
				break;
			}
		}

		
		for (int a = 0; a < 3; a++) {
			if ((button[0][a].getText() == "X" || button[1][a].getText() == "O")
					&& button[0][a].getText().equals(button[1][a].getText())
					&& button[1][a].getText().equals(button[2][a].getText())) {
						
				for (int a1 = 0; a1 < 3; a1++) {
					for (int s = 0; s < 3; s++) {
						button[a1][s].setEnabled(false);
					}
				}
				JLabel label = new JLabel("���� ����");
				panel2.add(label);
			}
		}
		

		for (int a = 0; a < 3; a++) {
			if ((button[a][0].getText() == "X" || button[a][0].getText() == "O")
					&& button[a][0].getText().equals(button[a][1].getText())
					&& button[a][1].getText().equals(button[a][2].getText())) {
				
				for (int a1 = 0; a1 < 3; a1++) {
					for (int s = 0; s < 3; s++) {
						button[a1][s].setEnabled(false);
					}
				}
				JLabel label = new JLabel("���� ����");
				panel2.add(label);
			}
		}

	
		if ((button[0][0].getText() == "X" || button[0][0].getText() == "O")
				&& button[0][0].getText().equals(button[1][1].getText())
				&& button[1][1].getText().equals(button[2][2].getText())
				&& button[0][0].getText().equals(button[2][2].getText())) {
			for (int a = 0; a < 3; a++) {
				for (int s = 0; s < 3; s++) {
					button[a][s].setEnabled(false);
				}
			}
			JLabel label = new JLabel("���� ����");
			panel2.add(label);
		}

		if ((button[0][2].getText() == "X" || button[0][2].getText() == "O")
				&& button[0][2].getText().equals(button[1][1].getText())
				&& button[1][1].getText().equals(button[2][0].getText())
				&& button[0][2].getText().equals(button[2][0].getText())) {
			
			for (int a = 0; a < 3; a++) {
				for (int s = 0; s < 3; s++) {
					button[a][s].setEnabled(false);
				}
			}
			JLabel label = new JLabel("���� ����");
			panel2.add(label);
		}
	}

	public static void main(String argv[]) {
		tic t = new tic();
	}
}

