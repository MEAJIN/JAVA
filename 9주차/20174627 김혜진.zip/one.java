import javax.swing.*;
import java.awt.*;

public class one extends JFrame{
	
	public one() {
		  setSize(300, 150);
		  setLocation(200, 300);
		  setTitle("MyFrame");
		  setVisible(true);
		  setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		  Object color;
		  
		  setLayout(new FlowLayout());
		  JButton button1 = new JButton("Yes");
		  JButton button2 = new JButton("No");
		  
		  JLabel label = new JLabel("�ڹٴ� ����ֳ���?");
		  this.add(label);

		  this.add(button1);
		  this.add(button2);


}

	public static void main(String[] args) {

		  one o = new one();
		
	}

}
