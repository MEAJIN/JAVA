import javax.swing.*;
import java.awt.*;

public class two extends JFrame {
	
	public two()
	{
		setSize(600, 500);
		setLocation(100, 300);
		setTitle("MyFrame");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		this.setLayout(null);
		
		int a, s;
		
		for(int q = 0; q < 50; q++)
		{
			JButton j = new JButton(q+"");
			
			a = (int)(Math.random()*500);
			s = (int)(Math.random()*400);
			
			j.setSize(50, 20);
			j.setLocation(a, s);
			
			this.add(j);
		}
		
		setVisible(true);
	}

	public static void main(String[] args) {
			
		two t = new two();

	}

}
